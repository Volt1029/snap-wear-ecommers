package com.snapwear3.request;

public class DeleteProductRequest {
	
//	private Long 

}
