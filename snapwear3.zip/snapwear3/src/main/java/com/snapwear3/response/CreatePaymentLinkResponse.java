package com.snapwear3.response;

public class CreatePaymentLinkResponse {
	
	

}
