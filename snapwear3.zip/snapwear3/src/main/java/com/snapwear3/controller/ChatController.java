package com.snapwear3.controller;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;

@RestController
@RequestMapping("/api")
public class ChatController {

	@PostMapping("/message")
	public Map<String, String> sendMessage( @RequestBody String message) {
	    RestTemplate restTemplate = new RestTemplate();
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.setBearerAuth("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");

	    // Use Jackson to create the JSON object for request body
	    ObjectMapper objectMapper = new ObjectMapper();
	    ObjectNode requestBodyNode = objectMapper.createObjectNode();
	    requestBodyNode.put("model", "llama3-8b-8192");

	    // Create message node and add it to the JSON structure
	    ObjectNode messageNode = objectMapper.createObjectNode();
	    messageNode.put("role", "user");
	    messageNode.put("content", message);
	    requestBodyNode.set("messages", objectMapper.createArrayNode().add(messageNode));

	    // Convert ObjectNode to String
	    String requestBody = requestBodyNode.toString();

	    // Create an HttpEntity with headers and the JSON request body
	    HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);

	    ResponseEntity<String> response = restTemplate.exchange(
	        "https://api.groq.com/openai/v1/chat/completions",
	        HttpMethod.POST,
	        entity,
	        String.class
	    );

	    String content = "";
	    try {
	        JsonNode rootNode = objectMapper.readTree(response.getBody());
	        JsonNode choicesNode = rootNode.path("choices");

	        if (choicesNode.isArray() && choicesNode.size() > 0) {
	            JsonNode messageNodeContent = choicesNode.get(0).path("message");
	            content = messageNodeContent.path("content").asText();
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    Map<String, String> res = new HashMap<>();
	    res.put("response", content);

	    return res;
	}

}
