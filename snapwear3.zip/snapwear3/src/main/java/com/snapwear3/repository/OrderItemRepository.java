package com.snapwear3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.snapwear3.modal.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

}
