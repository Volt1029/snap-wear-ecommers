package com.snapwear3.config;

public class JwtConstant {
	
	public static final String SECRET_KEY="wpembytrwcvnryxksdbqwjebruyGHyudqgwveytrtrCSnwifoesarjbwa";
	public static final String JWT_HEADER="Authorization";

}
