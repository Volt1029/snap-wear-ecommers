package com.snapwear3.exception;

public class ProductException extends Exception{
	
	public ProductException(String message) {
		super(message);
	}

}
