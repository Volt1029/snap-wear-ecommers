package com.snapwear3.exception;

public class OrderException extends Exception {
	
	public OrderException(String message) {
		super(message);
	}

}
