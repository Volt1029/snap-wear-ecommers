package com.snapwear3.service;

import java.util.List;

import com.snapwear3.exception.ProductException;
import com.snapwear3.modal.Rating;
import com.snapwear3.modal.User;
import com.snapwear3.request.RatingRequest;

public interface RatingServices {
	
	public Rating createRating(RatingRequest req,User user) throws ProductException;
	
	public List<Rating> getProductsRating(Long productId);

}
