package com.snapwear3.service;

import java.util.List;

import com.snapwear3.exception.ProductException;
import com.snapwear3.modal.Review;
import com.snapwear3.modal.User;
import com.snapwear3.request.ReviewRequest;

public interface ReviewService {

	public Review createReview(ReviewRequest req,User user) throws ProductException;
	
	public List<Review> getAllReview(Long productId);
	
	
}
