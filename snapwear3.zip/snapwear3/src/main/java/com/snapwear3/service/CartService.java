package com.snapwear3.service;

import com.snapwear3.exception.ProductException;
import com.snapwear3.modal.Cart;
import com.snapwear3.modal.CartItem;
import com.snapwear3.modal.User;
import com.snapwear3.request.AddItemRequest;

public interface CartService {
	
	public Cart createCart(User user);
	
	public CartItem addCartItem(Long userId,AddItemRequest req) throws ProductException;
	
	public Cart findUserCart(Long userId);

}
