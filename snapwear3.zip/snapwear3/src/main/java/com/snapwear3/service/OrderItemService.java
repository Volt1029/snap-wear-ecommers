package com.snapwear3.service;

import com.snapwear3.modal.OrderItem;

public interface OrderItemService {
	
	public OrderItem createOrderItem(OrderItem orderItem);

}
