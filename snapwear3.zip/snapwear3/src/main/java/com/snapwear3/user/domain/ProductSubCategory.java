package com.snapwear3.user.domain;

public enum ProductSubCategory {
	
	SHIRT,
	TSHIRT,
	SHOES,
	PAINT,
	SAREE,
	KURTA,
	WATCH

}
