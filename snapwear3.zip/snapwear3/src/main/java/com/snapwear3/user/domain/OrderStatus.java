package com.snapwear3.user.domain;

public enum OrderStatus {
	PENDING,
    PLACED,
    CONFIRMED,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
