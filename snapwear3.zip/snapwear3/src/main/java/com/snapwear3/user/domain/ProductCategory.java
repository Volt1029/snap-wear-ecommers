package com.snapwear3.user.domain;

public enum ProductCategory {

	MALE,
	FEMALE
}
